# Prime Detail

Site de demonstração da Prime Detail, estética automotiva em Cascavel-PR.
Página única em HTML, CSS e JavaScript, com GSAP + ScrollTrigger (via CDN). Não precisa de build.

## Antes de publicar

Abra `index.html`, procure por `var NUM=` e troque pelo número real de WhatsApp (55 + DDD + número).

## Subir no GitHub

```bash
git init
git add .
git commit -m "Site Prime Detail"
git branch -M main
git remote add origin https://github.com/SEU-USUARIO/prime-detail.git
git push -u origin main
```

## Deploy na Vercel

1. Em vercel.com, clique em **Add New > Project** e importe o repositório.
2. Framework Preset: **Other**. Deixe Build Command e Output Directory em branco.
3. Clique em **Deploy**. Cada novo `git push` publica automaticamente.
